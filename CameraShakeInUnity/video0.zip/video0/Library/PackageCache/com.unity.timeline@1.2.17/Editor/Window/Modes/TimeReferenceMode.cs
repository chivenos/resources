namespace UnityEditor.Timeline
{
    enum TimeReferenceMode
    {
        Local = 0,
        Global = 1
    }
}
